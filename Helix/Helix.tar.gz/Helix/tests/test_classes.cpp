
#include "gtest/gtest.h"

// Test the various classes on their basic functionality as far as needed (might not be much at all)

// File, Result, Query (but not search!)
