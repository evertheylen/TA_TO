#ifndef _product
#define _product

#include "FSM.h"
#include "product.tcc"

#endif
