#ifndef _REeNFA
#define _REeNFA

#include "FSM.h"
#include <string>

bool isInAlphabet(std::string str, char c);

#include "RE-eNFA.tcc"


#endif
