#ifndef _eNFA
#define _eNFA

#include "FSM.h"
#include "eNFA-DFA.tcc"

#endif
