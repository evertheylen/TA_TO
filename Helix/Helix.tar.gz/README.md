
# Helix

Er zijn drie executables:

  - test (op basis van gtest)
  - convertor (om de algoritmes apart te testen, dot output)
  - Helix (de GUI)

## test

Instructies:
```
make gtest
make test
./test
```

## convertor

```
make convertor
```

Gebruik:

- `./convertor RE-eNFA "[regex]" [output_file]`
    - zet de eNFA op basis van regex in [output_file].
- `./convertor TFA [filename]`
    - leest de DFA in xml formaat in, output naar [filename].dot
- `./convertor eNFA-DFA [filename]`
    - leest de eNFA in xml formaat in, originele eNFA naar [filename].org_dot, DFA naar [filename].dot
- `./convertor union [DFA1] [DFA2] [output_file]` of `./convertor intersection [DFA1] [DFA2] [output_file]`
    - leest de DFA's in, zet het product in [output_file]
- `./convertor suffix [filename]`
    - maakt suffixtree van het bestand [filename], print dot naar [filename].dot (opgepast met grote bestanden)
- `./convertor suffixsearch [filename] [regex]`
    - bouwt suffixtree op, zoekt op de regex (zonder toegelaten fouten)
- `./convertor suffixsave [filename]`
    - bouwt suffixtree op, slaagt deze op in binair formaat in [filename].suffix

## Helix

```
make GUI
```

Deze executable is te vinden in `./GUI/Helix`.

Het meeste van de GUI is vrij intuïtief, maar opgepast met het knopje 'offload to disk', deze zal alle ingeladen bestanden in binair formaat opslagen, om zo ook hele grote genomen te kunnen laden. Het knopje 'Add directory' voegt alle binaire ('.suffix') bestanden van de gekozen directory toe.

Instructies over de mogelijke toegelaten fouten in een regex, vindt u in de help knop rechtsbovenaan het venster om resultaten te bekijken.
