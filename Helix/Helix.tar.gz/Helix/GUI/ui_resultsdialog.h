/********************************************************************************
** Form generated from reading UI file 'resultsdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RESULTSDIALOG_H
#define UI_RESULTSDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>
#include <qwindow.h>

QT_BEGIN_NAMESPACE

class Ui_resultsdialog
{
public:
    QGridLayout *gridLayout_2;
    QHBoxLayout *horizontalLayout;
    QLabel *label_3;
    QLabel *filename;
    QLabel *label;
    QLabel *searchstring;
    QGridLayout *gridLayout;
    QTableWidget *tableWidget;
    QPushButton *gobackttomainfromresults;

    void setupUi(QWindow *resultsdialog)
    {
        if (resultsdialog->objectName().isEmpty())
            resultsdialog->setObjectName(QStringLiteral("resultsdialog"));
        resultsdialog->resize(634, 366);
        gridLayout_2 = new QGridLayout(resultsdialog);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        label_3 = new QLabel(resultsdialog);
        label_3->setObjectName(QStringLiteral("label_3"));

        horizontalLayout->addWidget(label_3);

        filename = new QLabel(resultsdialog);
        filename->setObjectName(QStringLiteral("filename"));

        horizontalLayout->addWidget(filename);

        label = new QLabel(resultsdialog);
        label->setObjectName(QStringLiteral("label"));

        horizontalLayout->addWidget(label);

        searchstring = new QLabel(resultsdialog);
        searchstring->setObjectName(QStringLiteral("searchstring"));

        horizontalLayout->addWidget(searchstring);


        gridLayout_2->addLayout(horizontalLayout, 0, 0, 1, 1);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        tableWidget = new QTableWidget(resultsdialog);
        if (tableWidget->columnCount() < 7)
            tableWidget->setColumnCount(7);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(5, __qtablewidgetitem5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(6, __qtablewidgetitem6);
        tableWidget->setObjectName(QStringLiteral("tableWidget"));
        tableWidget->horizontalHeader()->setDefaultSectionSize(90);
        tableWidget->horizontalHeader()->setMinimumSectionSize(20);

        gridLayout->addWidget(tableWidget, 0, 0, 1, 1);

        gobackttomainfromresults = new QPushButton(resultsdialog);
        gobackttomainfromresults->setObjectName(QStringLiteral("gobackttomainfromresults"));

        gridLayout->addWidget(gobackttomainfromresults, 1, 0, 1, 1);


        gridLayout_2->addLayout(gridLayout, 1, 0, 1, 1);


        retranslateUi(resultsdialog);

        QMetaObject::connectSlotsByName(resultsdialog);
    } // setupUi

    void retranslateUi(QWindow *resultsdialog)
    {
        resultsdialog->setWindowTitle(QApplication::translate("resultsdialog", "Dialog", 0));
        label_3->setText(QApplication::translate("resultsdialog", "File: ", 0));
        filename->setText(QApplication::translate("resultsdialog", "TextLabel", 0));
        label->setText(QApplication::translate("resultsdialog", "Query:", 0));
        searchstring->setText(QApplication::translate("resultsdialog", "TextLabel", 0));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("resultsdialog", "Match", 0));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("resultsdialog", "Locations", 0));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("resultsdialog", "Total errors", 0));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("resultsdialog", "Fake", 0));
        QTableWidgetItem *___qtablewidgetitem4 = tableWidget->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QApplication::translate("resultsdialog", "Skip", 0));
        QTableWidgetItem *___qtablewidgetitem5 = tableWidget->horizontalHeaderItem(5);
        ___qtablewidgetitem5->setText(QApplication::translate("resultsdialog", "Repetition", 0));
        QTableWidgetItem *___qtablewidgetitem6 = tableWidget->horizontalHeaderItem(6);
        ___qtablewidgetitem6->setText(QApplication::translate("resultsdialog", "Ignore", 0));
        gobackttomainfromresults->setText(QApplication::translate("resultsdialog", "Go back", 0));
    } // retranslateUi

};

namespace Ui {
    class resultsdialog: public Ui_resultsdialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RESULTSDIALOG_H
